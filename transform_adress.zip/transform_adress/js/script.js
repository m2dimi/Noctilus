// JavaScript Document
function recupAdress() 
{ 
var adresse = document.getElementById("adresse").value; 
alert(adresse); 
}

function transformAdress(){
	var transform= getUrl('http://maps.googleapis.com/maps/api/geocode/json?sensor=false&address=') + encodeURI(adresse)
alert(transform);	
}




   