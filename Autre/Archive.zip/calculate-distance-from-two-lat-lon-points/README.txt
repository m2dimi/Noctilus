A Pen created at CodePen.io. You can find this one at http://codepen.io/danieleguido/pen/pvzVdr.

 Using d3.geo, we rougly calulate a distance from two lat/lon points