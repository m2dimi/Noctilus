// JavaScript Document
function recupAdress() 
{ 
var adresse = document.getElementById("adresse").value; 
alert(adresse); 
}



   